#!/bin/bash

./node_modules/.bin/ember build --environment production
